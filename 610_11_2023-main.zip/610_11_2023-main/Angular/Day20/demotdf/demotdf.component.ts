import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demotdf',
  templateUrl: './demotdf.component.html',
  styleUrls: ['./demotdf.component.css']
})
export class DemotdfComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
