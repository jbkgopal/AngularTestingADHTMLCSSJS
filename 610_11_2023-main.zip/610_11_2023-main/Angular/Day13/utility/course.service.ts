
export class CourseService{
    private course:string[]=['Core Java','Advanced java','Spring Boot','JSP','Angular 12','AWS','Docker'];


    


    getCourse(){
        return this.course;
    }
}