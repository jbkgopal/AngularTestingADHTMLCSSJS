import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-queryparameter',
  templateUrl: './queryparameter.component.html',
  styleUrls: ['./queryparameter.component.css']
})
export class QueryparameterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
