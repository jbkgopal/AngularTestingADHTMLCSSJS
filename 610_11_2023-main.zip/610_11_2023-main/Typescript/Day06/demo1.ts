//control statement
// if,if-else,nested if-else,switch,break,continue

var s1=4;

// if(s1>4){
//     console.log("Condition is true");
// }else{
//     console.log("Condition is False");
// }

// if(s1>4){
//     console.log("Condition is true");
// }else if(s1==4){
//     console.log("Condition is equal");
// }else{
//     console.log("Condition is False");
// }


//switch
var choice:number=21;

// switch(choice){
//     case 1:console.log("u r in case 1");
//             break;
//     case 2 : console.log("u r in case 2");
//             break;
//     default:console.log("u r in default case");
//             break;
// }


//Loop statement
//while ,do-while,for ,foreach

var count=5;
// while(count!=0){
//     console.log("Count is "+count);
//     count--;
// }

// do{
//     console.log("Count is "+count);
//     count--;
// }while(count!=0)

var b1:number=11;

// do{
//     console.log("Count is "+count)
//     count++;
// }while(count<=10);



// for loop

// for(var i=0;i<5;i++){
//     console.log("value of i "+i)
// }
// console.log("Value of i after loop "+i);

// var => variable has global scope

//let => it is keyword to create a variable 
// scope => its has within nearest block ({})

for(let i=0;i<5;i++){
    console.log("value of i "+i)
}

// console.log("Value of i after loop "+i);

// const => it is keyword to create variable but its value is constant 
const pi=3.14;
// scope => it has global scope as well as local scope 






