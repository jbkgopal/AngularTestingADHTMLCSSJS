import {Myclass,add1,pi} from './demo1';

let obj=new Myclass(3,'Spruha','Raokhande');
obj.display();

console.log(`
    ------- Addition ---------
    ${add1(2,3)}
`)

console.log("Pi is "+pi)