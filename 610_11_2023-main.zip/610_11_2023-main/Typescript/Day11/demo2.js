"use strict";
exports.__esModule = true;
var demo1_1 = require("./demo1");
var obj = new demo1_1.Myclass(3, 'Spruha', 'Raokhande');
obj.display();
console.log("\n    ------- Addition ---------\n    ".concat((0, demo1_1.add1)(2, 3), "\n"));
console.log("Pi is " + demo1_1.pi);
