
import {Myclass} from '../Day11/demo1';

let obj=new Myclass(6,'Kiran','Raokhande');
obj.display();
