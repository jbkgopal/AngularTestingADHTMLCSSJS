"use strict";
exports.__esModule = true;
var demo1_1 = require("../Day11/demo1");
var obj = new demo1_1.Myclass(6, 'Kiran', 'Raokhande');
obj.display();
