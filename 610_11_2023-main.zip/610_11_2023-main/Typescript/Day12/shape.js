"use strict";
exports.__esModule = true;
exports.Shape = void 0;
var Shape = /** @class */ (function () {
    function Shape() {
    }
    Shape.prototype.myArea = function () {
        console.log("U r in Shape Class");
    };
    return Shape;
}());
exports.Shape = Shape;
