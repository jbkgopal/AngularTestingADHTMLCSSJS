import {Circle} from './circle';
import {Rectangle} from './rectangle';

let circleObj=new Circle(2);
circleObj.myArea();
circleObj.display();

let rectObj=new Rectangle(2,3);
rectObj.myArea();
rectObj.display();