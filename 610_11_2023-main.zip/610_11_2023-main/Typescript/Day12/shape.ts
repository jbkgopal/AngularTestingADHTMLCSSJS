
export class Shape {

       myArea(){
        console.log("U r in Shape Class");
       } 
}