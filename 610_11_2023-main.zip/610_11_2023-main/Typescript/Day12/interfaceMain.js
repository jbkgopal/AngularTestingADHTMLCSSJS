"use strict";
exports.__esModule = true;
var employeedetails_1 = require("./employeedetails");
var obj = new employeedetails_1.EmployeeDetails('Sumit', 'Raokhande', 100000, 'DevOps');
obj.display();
