import {EmployeeDetails} from './employeedetails';

let obj=new EmployeeDetails('Sumit','Raokhande',100000,'DevOps');
obj.display();