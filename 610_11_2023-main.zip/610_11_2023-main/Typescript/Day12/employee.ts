export interface Employee{
    fname:string;
    lname:string;
    fullname?:string;

    display();
}