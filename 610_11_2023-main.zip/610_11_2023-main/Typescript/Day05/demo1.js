//variable
var a1, a_2;
var a$b, ab;
//Data types
// number(int,long,short,double,float),string(""/''/``),boolean(true/false)
// any (number,string,boolean)
// void => it is neutral data type => it does not point anything => we can not store any data types value 
// misec null & undefined => we store as value or we can assign as data type => it can be used data type as well as value 
var a = 10; // forward declaration & defination
//console.log("Value of a "+a);
/*
console.log('Value of a '+a);
console.log(`
        Value of a ${a}
`)
*/
var str;
// console.log("Value of str is "+str)
str = 'Sumit';
// console.log("Value of Str is "+str);
var myany;
myany = 2.5;
console.log('My any value is ' + myany);
myany = "Sumit raokhande";
console.log('My any value is ' + myany);
myany = true;
console.log('My any value is ' + myany);
