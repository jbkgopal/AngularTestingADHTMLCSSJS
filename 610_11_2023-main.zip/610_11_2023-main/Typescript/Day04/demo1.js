console.log("Hello World");
console.log('Welcome to angular 12 module');
console.log("\n            Hopes so u all r enjoy!!!!!\n");
