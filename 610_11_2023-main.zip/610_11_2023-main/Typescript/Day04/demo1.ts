
console.log("Hello World");
console.log('Welcome to angular 12 module')
console.log(`
            Hopes so u all r enjoy!!!!!
`);



