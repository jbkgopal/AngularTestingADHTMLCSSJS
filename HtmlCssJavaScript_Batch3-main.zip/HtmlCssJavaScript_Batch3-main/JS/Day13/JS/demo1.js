console.log("My First JS Module Lecture...")

document.write('My First JS Module Lecture...')