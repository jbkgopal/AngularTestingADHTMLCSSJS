
//annonymous function

let temp=function (){
  console.log("Function does not have any name...")
}

// temp();

let temp2=function (a,b){
  return (a+b);
}

let res=temp2(6,6);
// console.log("Result is "+res);



// fat arrow function/Arrow function

let temp3=()=>{
  console.log("Fat arrow function is called...")
}

// temp3();

let temp4=(a,b)=>{
 return (a+b);
}

let res3=temp4(7,4);
console.log("Result is "+res3);





