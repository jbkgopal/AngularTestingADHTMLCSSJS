
function MyChange(){
  console.log("Change event Occur...")
  let inputname=document.getElementById("inputname");
  inputname.style.background='green';
  inputname.style.color='white';
}