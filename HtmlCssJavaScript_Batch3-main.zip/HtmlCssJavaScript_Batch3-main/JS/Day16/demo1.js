
let a=[3,4,55,6,7];

a.forEach((myvalue,i,arr)=>{

  console.log("myvalue data is "+myvalue+" Index is "+i)

})