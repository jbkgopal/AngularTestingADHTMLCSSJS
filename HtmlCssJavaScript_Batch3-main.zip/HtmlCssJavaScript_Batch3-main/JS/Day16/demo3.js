// json objecct
//java script object Notation
// we can save data is in key & value format

let jsonObj={
  fname:'Sumit',
  lname:"Raokhande",
  id:9
}
console.log("First Name:: "+jsonObj.fname);
console.log("Last Name:: "+jsonObj.lname);
console.log("ID       :: "+jsonObj.id);

