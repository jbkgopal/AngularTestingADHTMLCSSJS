// console.log("Hello World...")
/** */

var a1;
a1=2.5;
// console.log('Value of a1 is '+a1)
// a1='Sumit';
// console.log('Value of a1 is '+a1)
// a1=true;
// console.log('Value of a1 is '+a1)

// Operators
//Airthemathic => +,-,/,*,%
// Logical => &&,||
// Bitwise => &,|,^,>>,<<,!,~
// ternary operator => condition?Expression1:expression2
// Unary => ++/--, post/pre, inc/dec
// Assignment => =,+=,-=,/=,*=,
//Relational => <=,>=,!=,==(it checks only data),
// === (Strongly equality / strictly Equality)
// It checks value as well as as its datatype
// a===b


// Control Statement
// if, if-else,nested if-else,switch,break,goto,continue

  // if(21<4){
  //   console.log("Condition is true")
  // }else{
  //   console.log("Condition is false")
  // }
var choice=2;

// switch(choice){
//   case 1: console.log("U r in Case 1");
//           break;
//   case 2 : console.log("U r in Case 2");
//            break;
//   default : console.log("U r in default case...")
//           break;
// }

//Loop 
//Do-while,while,for,foreach
// do-while

var count=5;
// do{
//   console.log("Count is "+count)
//   count--;
// }while(count!=0)

// while(count!=0){
//   console.log("Count is "+count)
//   count--;
// }

// Core java 
// for (initilizer;condition;inc/dec){}
// for(int i=0;i<4;i++){}

// for (var i=0;i<5;i++){
//   console.log("Value of i is "+i);
// }

// for (var i=0;i<5;i++){
//     console.log("Value of i is "+i);
// }
//   console.log("Value of i after loop "+i);

// var has global scope

// let keyword
// let has scope within nearest block({})

// for(let i=0;i<5;i++){
//   console.log("Value of i is "+i);
// }

// console.log("Value of i after loop "+i);

//const 
const pi=3.14; // forward declaration & defination
console.log("Pi value is "+pi)

// const has global scope as well as local scope
