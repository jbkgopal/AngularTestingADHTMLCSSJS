package com.tha.properties;

import com.tha.config.Config;

public class DemoProperties extends Config {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DemoProperties obj=new DemoProperties();
		//obj.readFile();
		obj.browserSetting();

	}

}
