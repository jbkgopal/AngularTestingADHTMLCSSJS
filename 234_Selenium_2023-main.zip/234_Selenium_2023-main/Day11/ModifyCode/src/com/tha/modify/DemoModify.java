package com.tha.modify;

import com.tha.config.ConfigDemo;

public class DemoModify {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConfigDemo obj=new ConfigDemo();
		obj.browserSetting("file:///D:/SeleniumSoftware/Offline%20Website/index.html");
		obj.loginAccess();
		
	}

}
