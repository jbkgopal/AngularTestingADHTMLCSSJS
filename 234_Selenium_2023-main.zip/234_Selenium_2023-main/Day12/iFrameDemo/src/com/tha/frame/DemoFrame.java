package com.tha.frame;

import com.tha.config.Config;

public class DemoFrame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Config obj=new Config();
		
		obj.browsrSetting("https://www.qa.jbktest.com/");
		obj.AccessiFrame();

	}

}
