package com.excelsheet;

import com.config.config;

public class DemoExcesheet extends config {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoExcesheet obj=new DemoExcesheet();
//		obj.readExcelSheet();
		obj.readExcelSheetAllData();
		
	}

}
