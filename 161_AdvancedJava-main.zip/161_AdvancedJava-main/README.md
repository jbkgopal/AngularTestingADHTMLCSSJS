# 161_AdvancedJava

Youtube Channel https://www.youtube.com/c/SumitNiche

linkedin.com/in/ sumit-raokhande-09aaba21

github.com/ sumitrao007

sumitrao007.github.io

See The Spring Boot Series https://www.youtube.com/watch?v=1cecOdE2ZN8&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm

https://www.youtube.com/watch?v=1cecOdE2ZN8&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=1

https://www.youtube.com/watch?v=NJaZMBH1M70&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=2

https://www.youtube.com/watch?v=0dudLT-fnrg&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=3

https://www.youtube.com/watch?v=gl4onrUJLUw&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=4

https://www.youtube.com/watch?v=XrX5Iu_Ri2k&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=5

https://www.youtube.com/watch?v=UzL160N7M8g&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=6

https://www.youtube.com/watch?v=RDfwnHWF_Rg&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=7

https://www.youtube.com/watch?v=py3GAGVEpu4&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=8

https://www.youtube.com/watch?v=qE0B6DsPTr4&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=9

https://www.youtube.com/watch?v=yAldDf9lVqY&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=10

https://www.youtube.com/watch?v=yOoTBBZjG_4&list=PLa3i9wpSPojGRBeYmmhVkl76bmqih4vGm&index=11

See the Angular 8 Series https://youtube.com/playlist?list=PLa3i9wpSPojEDNTe66s5XhXPSd50XqjSv

1 https://www.youtube.com/watch?v=jBBTYKIgNT8&list=PLa3i9wpSPojEDNTe66s5XhXPSd50XqjSv&index=2&t=12s

2 https://www.youtube.com/watch?v=qbuBY_xa57Q&list=PLa3i9wpSPojEDNTe66s5XhXPSd50XqjSv&index=2

3 https://www.youtube.com/watch?v=4Mn7ZILjwHs&list=PLa3i9wpSPojEDNTe66s5XhXPSd50XqjSv&index=3

4 https://www.youtube.com/watch?v=DX3jiyQmTjo&list=PLa3i9wpSPojEDNTe66s5XhXPSd50XqjSv&index=4

5 https://www.youtube.com/watch?v=cwj9QrOu1w8&list=PLa3i9wpSPojEDNTe66s5XhXPSd50XqjSv&index=5

6 https://www.youtube.com/watch?v=bOYj5rdEfPM&list=PLa3i9wpSPojEDNTe66s5XhXPSd50XqjSv&index=6

See The Angular Project Series https://youtube.com/playlist?list=PLa3i9wpSPojEjJLQvdi4G4UXtd0pcKrZh

1 https://youtu.be/SmqIB2d-Xbg

2 https://youtu.be/5lKwN6rngF0

3 https://youtu.be/Zgmw-GW5kZc

4 https://youtu.be/GbP-BS_nb3Q

5 https://youtu.be/e9-F4P_ChTs

6 https://youtu.be/gh83484qW_8

7 https://youtu.be/VLv5labtAjk

8 https://youtu.be/7SRHWQrghqY

9 https://youtu.be/MnmrXTnqt4o
