package com.tka.ProjectDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
