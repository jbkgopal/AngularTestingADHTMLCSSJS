package com.tka.DemoMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
