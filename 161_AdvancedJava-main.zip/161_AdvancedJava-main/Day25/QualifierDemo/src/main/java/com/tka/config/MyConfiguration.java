package com.tka.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = {"com.tka"})
public class MyConfiguration {

}
