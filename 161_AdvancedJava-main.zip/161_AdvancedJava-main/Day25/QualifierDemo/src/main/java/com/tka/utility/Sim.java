package com.tka.utility;

public interface Sim {

	public String calling();
	
}
