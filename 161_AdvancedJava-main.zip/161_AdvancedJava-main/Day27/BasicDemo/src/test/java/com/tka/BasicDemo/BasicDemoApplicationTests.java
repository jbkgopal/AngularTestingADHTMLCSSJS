package com.tka.BasicDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
